package com.ugo.android.gadsleaderboard.model;

public class SubmissionResponseModel {
}
